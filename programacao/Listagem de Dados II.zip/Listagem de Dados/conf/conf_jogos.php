<?php
	date_default_timezone_set('America/Sao_Paulo');

	$url = "127.0.0.1"; 
	$dbname = "CRUD"; 
	$usuario = "root"; 
	$password = ""; 

	$tb_marca = "Jogo";
?>