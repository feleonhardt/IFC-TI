<?php
	date_default_timezone_set('America/Sao_Paulo');

	$url = "127.0.0.1"; 
	$dbname = "CRUD"; 
	$usuario = "root"; 
	$password = ""; 

	$tb_marca = "Marca";
	$tb_aluno = "Aluno";
	$tb_bicicleta = "Bicicleta";
	$tb_computador = "Computador";
	$tb_carro = "Carro";
	$tb_cliente = "Cliente";
	$tb_email = "Email";
	$tb_enchente = "Enchente";
	$tb_escola = "Escola";
	$tb_esporte = "Esporte";
	$tb_estado = "Estado";
	$tb_funcionario = "Funcionario";
	$tb_jogador = "Jogador";
	$tb_jogo = "Jogo";
	$tb_pais = "Paises";
	$tb_predio = "Predio";
	$tb_time = "Time_futebol";
	$tb_vendedor = "Vendedor";
?>