<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="Assets/style.css" />
    <meta charset="UTF-8" />
    <link rel="shortcut icon" type="image/x-icon" href="Assets/php.png" />
    <title>Exercicio 16 | Calculo</title>
</head>
<body>
<div>
  <?php
    $mtsTinta= isset($_POST["mts"])?$_POST["mts"]:"9";
    $latasA = ceil($mtsTinta / 108);
    $latasB = ceil($mtsTinta / 21.6);
    $custoA = $latasA * 80;
    $custoB = $latasB * 25;
  ?>
  <h1>Calculo</h1>
  <br>
  <ul>
    <li><?php echo "Para pintar ".$mtsTinta." m² com latas de 3,6l  será necessário(s) ".$latasB." lata(s) a um custo total de RS ".$custoB; ?></li>
    <li><?php echo "Para pintar ".$mtsTinta." m² com latas de 18l  será necessário(s) ".$latasA." lata(s) a um custo total de RS ".$custoA; ?></li>
  </ul>
</div>
</body>
</html>
