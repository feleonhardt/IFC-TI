<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="Assets/style.css" />
    <meta charset="UTF-8" />
    <link rel="shortcut icon" type="image/x-icon" href="Assets/php.png" />
    <title>Exercicio 06</title>
</head>
<body>
<div>
  <?php
    $R = $_POST['r'];
    $pi = 3.14;
    $area = $pi * ($R * $R);
  ?>
  <h1>Area de circula</h1>
  <ul>
    <li><?php echo "Area do circulo: ".$area; ?></li>
  </ul>
</div>
</body>
</html>
