<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="Assets/style.css" />
    <meta charset="UTF-8" />
    <link rel="shortcut icon" type="image/x-icon" href="Assets/php.png" />
    <title>Exercicio 01</title>
</head>
<body>
<div>
  <?php
      $texto = $_POST['txt'];
  ?>
  <h1>Texto: </h1>
  <p>
    <?php echo $texto; ?>
  </p>
</div>
</body>
</html>
