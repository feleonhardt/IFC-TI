<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="Assets/style.css" />
    <meta charset="UTF-8" />
    <link rel="shortcut icon" type="image/x-icon" href="Assets/php.png" />
    <title>Exercicio 05</title>
</head>
<body>
<div>
  <?php
    $metros = $_POST['m'];
    $cent = $metros * 100;
  ?>
  <h1>Conversor de Metros para Centimetros</h1>
  <ul>
    <li><?php echo $metros." Metros para Centimetros é: ".$cent; ?></li>
  </ul>
</div>
</body>
</html>
