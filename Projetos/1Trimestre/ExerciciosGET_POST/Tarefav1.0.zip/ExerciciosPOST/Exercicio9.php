<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="Assets/style.css"/>
  <meta charset="UTF-8"/>
  <title>Exercicio 9 | Calculo</title>
</head>
<body>
<div>
    <?php
      $F = isset($_POST["f"])?$_POST["f"]:"9";
      $C = ceil(($F-32)/1.8);
    ?>
    <h1>Temperatura</h1>
    <ul>
      <li><?php echo $C." Graus Celsius."; ?></li>
    </ul>
</div>
</body>
</html>
