<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="Assets/style.css" />
    <meta charset="UTF-8" />
    <link rel="shortcut icon" type="image/x-icon" href="Assets/php.png" />
    <title>Exercicio 08 | Calculos</title>
</head>
<body>
<div>
  <?php
  $phora = $_POST['ph'];
  $hora = $_POST['h'];
  $total = $hora * $phora;
  ?>
  <h1>Calculo de Salario</h1>
  <ul>
    <li><?php echo "Seu sálario é de RS ".$total; ?></li>
  </ul>
</div>
</body>
</html>
