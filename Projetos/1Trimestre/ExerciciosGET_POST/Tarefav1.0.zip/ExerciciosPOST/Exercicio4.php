<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="Assets/style.css" />
    <meta charset="UTF-8" />
    <link rel="shortcut icon" type="image/x-icon" href="Assets/php.png" />
    <title>Exercicio 04</title>
</head>
<body>
<div>
  <?php
    $nota1 = $_POST['n1'];
    $nota2 = $_POST['n2'];
    $nota3 = $_POST['n3'];
    $nota4 = $_POST['n4'];
    $media = ($nota1 + $nota2 + $nota3 + $nota4) / 4;
  ?>
  <h1>Média</h1>
  <ul>
    <li><?php echo "Média: ".$media; ?></li>
  </ul>
</div>
</body>
</html>
