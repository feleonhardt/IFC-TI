<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="Assets/style.css" />
    <meta charset="UTF-8" />
    <link rel="shortcut icon" type="image/x-icon" href="Assets/php.png" />
    <title>Exercicio 13 | Calculo</title>
</head>
<body>
<div>
  <?php
    $peso = isset($_POST["p"])?$_POST["p"]:50;
    if ($peso > 50) {
      $ex = $peso - 50;
      $multa = $ex * 4;
      $resp = "Sua multa é de: R$ $multa.";
    }
    else {
      $resp = "Você não tem multa.";
    }
  ?>
  <h1>Calculo de multa</h1>
  <br>
  <ul>
    <li><?php echo $resp; ?></li>
  </ul>
</div>
</body>
</html>
