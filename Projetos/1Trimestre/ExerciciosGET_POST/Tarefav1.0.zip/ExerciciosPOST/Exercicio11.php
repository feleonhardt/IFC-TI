<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="Assets/style.css" />
    <meta charset="UTF-8" />
    <link rel="shortcut icon" type="image/x-icon" href="Assets/php.png" />
    <title>Exercicio 12 | Calculo</title>
</head>
<body>
<div>
  <?php
    $h = isset($_POST["a"])?$_POST["a"]: "1.60";
    $pesoIdeal = (72.7 * $h) - 58;
  ?>
  <h1>Peso ideal: </h1>
  <ul>
    <li><?php echo "Seu peso ideal é: ".$pesoIdeal. "Kg"; ?></li>
  </ul>
</div>
</body>
</html>
