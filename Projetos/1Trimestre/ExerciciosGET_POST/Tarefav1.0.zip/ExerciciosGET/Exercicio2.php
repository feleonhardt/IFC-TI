<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="Assets/style.css" />
    <meta charset="UTF-8" />
    <link rel="shortcut icon" type="image/x-icon" href="Assets/php.png" />
    <title>Exercicio 02</title>
</head>
<body>
<div>
  <?php
    $n1 = $_GET['n1'];
  ?>
  <h1>Número: </h1>
  <p>
    <?php echo $n1; ?>
  </p>
</div>
</body>
</html>
