<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="Assets/style.css" />
    <meta charset="UTF-8" />
    <link rel="shortcut icon" type="image/x-icon" href="Assets/php.png" />
    <title>Exercicio 10 | Calculo</title>
</head>
<body>
<div>
  <?php
    $num1 = isset($_GET["n1"])?$_GET("n1"):"3";
    $num2 = isset($_GET["n2"])?$_GET("n2"):"9";
    $num3 = isset($_GET["n3"])?$_GET("n3"):"6.5";
    $a = ($num1 * 2) * ($num2 / 2);
    $b = ($num1 * 3) + $num3;
    $c = ($num3 * $num3 * $num3);
  ?>
  <h1>Calculo</h1>
  <ul>
    <li><?php echo "A: ".$a; ?></li>
    <li><?php echo "B: ".$b; ?></li>
    <li><?php echo "C: ".$c; ?></li>
  </ul>
</div>
</body>
</html>
