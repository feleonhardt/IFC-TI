<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="Assets/style.css" />
    <meta charset="UTF-8" />
    <link rel="shortcut icon" type="image/x-icon" href="Assets/php.png" />
    <title>Exercicio 07</title>
</head>
<body>
<div>
  <?php
    $l = $_GET['l'];
    $area = $l * $l;
  ?>
  <h1>Area de um quadrado</h1>
  <ul>
    <li>
      <?php echo "O quadrado possui ".$area. "m² de area."; ?>
    </li>
  </ul>
</div>
</body>
</html>
