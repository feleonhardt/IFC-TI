<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="Assets/style.css" />
    <meta charset="UTF-8" />
    <link rel="shortcut icon" type="image/x-icon" href="Assets/php.png" />
    <title>Exercicio 12 | Calculo</title>
</head>
<body>
<div>
  <?php
    $h = isset($_GET["a"])?$_GET["a"]:"1.7";
    $sexo = isset($_GET["s"])?$_GET["s"]:1;
    if ($sexo == 1) {
      $pesoIdeal = (72.7 * $h) - 58;
    }
    else {
      $pesoIdeal = (62.1 * $h) - 44.7;
    }
  ?>
  <h1>Calculo do Peso ideal</h1>
  <ul>
    <li><?php echo "Peso ideal: ".$pesoIdeal."Kg"; ?></li>
  </ul>
</div>
</body>
</html>
