<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="Assets/style.css" />
    <meta charset="UTF-8" />
    <link rel="shortcut icon" type="image/x-icon" href="Assets/php.png" />
    <title>Exercicio 03</title>
</head>
<body>
<div>
  <?php
    $n1 = $_GET['n1'];
    $n2 = $_GET['n2'];
    $soma = $n1 + $n2;
  ?>
  <h1>Soma</h1>
  <ul>
    <li><?php echo "A soma é: ".$soma; ?></li>
  </ul>
</div>
</body>
</html>
