<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="Assets/style.css" />
    <meta charset="UTF-8" />
    <link rel="shortcut icon" type="image/x-icon" href="Assets/php.png" />
    <title>Exercicio 14 | Calculo</title>
</head>
<body>
<div>
  <?php
    $nome = isset($_GET["nome"])?$_GET["nome"]:"João da Silva";
    $ganhoMes = isset($_GET["gm"])?$_GET["gm"]:"20";
    $horaTrab = isset($_GET["ht"])?$_GET["ht"]:"100";
    $salBruto = $ganhoMes * $horaTrab;
    $ir = $salBruto * 0.11;
    $inss = $salBruto * 0.08;
    $sind = $salBruto * 0.05;
    $descontos = $sind + $inss + $ir;
    $salLiquido = $salBruto - $descontos;
  ?>
  <h1>Calculo de Salário</h1>
  <br>
  <h2>Calculo referente a <?php echo $nome.":"; ?></h2>
  <ul>
    <li>
      <?php echo "Salário Bruto: R$".$salBruto; ?>
    </li>
    <li>
      <?php echo "Descontos do Imposto de Renda: R$".$ir; ?>
    </li>
    <li>
      <?php echo "Descontos do INSS: R$".$inss; ?>
    </li>
     <li>
      <?php echo "Descontos do Sindicato: R$".$sind; ?>
    </li>
    <li>
      <?php echo "Salário Liquido: R$".$salLiquido; ?>
    </li>
  </ul>
</div>
</body>
</html>
