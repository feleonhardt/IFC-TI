<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="Assets/style.css" />
    <meta charset="UTF-8" />
    <link rel="shortcut icon" type="image/x-icon" href="Assets/php.png" />
    <title>Exercicio 04</title>
</head>
<body>
<div>
  <?php
    $nota1 = $_GET['n1'];
    $nota2 = $_GET['n2'];
    $nota3 = $_GET['n3'];
    $nota4 = $_GET['n4'];
    $media = ($nota1 + $nota2 + $nota3 + $nota4) / 4;
  ?>
  <h1>Média</h1>
  <ul>
    <li><?php echo "Média: ".$media; ?></li>
  </ul>
</div>
</body>
</html>
