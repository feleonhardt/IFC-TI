<!DOCTYPE html>
<html lang="pt-BR" />
<?php $n1 = 9.5; $n2 = 7.6;$n3 = 9.8;$n4 = 10; $media = ($n1 + $n2 + $n4 +$n3) / 4 ?>
<head>
  <meta charset="UTF-8" />
  <title>Exercicio 1</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="assets/css/basico.css" />
  <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon" />
</head>

<body>
  <h1><?php echo $media; ?></h1>
</body>

</html>
