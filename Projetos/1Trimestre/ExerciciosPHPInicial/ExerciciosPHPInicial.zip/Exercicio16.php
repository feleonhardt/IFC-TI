<!DOCTYPE html>
<html lang="pt-BR" />
<?php $m = 589; $lataA = $m / 108;$cA = ceil($lataA * 80); $lataB = $m / 26.1;$cB = ceil($lataB * 25); ?>
<head>
  <meta charset="UTF-8" />
  <title>Exercicio 1</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="assets/css/basico.css" />
  <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon" />
</head>

<body>
  <h1><?php echo $cA; ?></h1>
  <h1><?php echo $cB; ?></h1>
</body>

</html>
