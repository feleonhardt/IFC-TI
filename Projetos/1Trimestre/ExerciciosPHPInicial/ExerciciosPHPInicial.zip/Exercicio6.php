<!DOCTYPE html>
<html lang="pt-BR" />
<?php $l = 4;$area = $l * $l; ?>
<head>
  <meta charset="UTF-8" />
  <title>Exercicio 1</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="assets/css/basico.css" />
  <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon" />
</head>

<body>
  <h1><?php echo $area; ?></h1>
</body>

</html>
