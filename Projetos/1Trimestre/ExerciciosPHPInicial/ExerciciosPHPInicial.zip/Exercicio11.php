<!DOCTYPE html>
<html lang="pt-BR" />
<?php $h = 1.70; $p = (72.7 * $h) - 58; ?>
<head>
  <meta charset="UTF-8" />
  <title>Exercicio 1</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="assets/css/basico.css" />
  <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon" />
</head>

<body>
  <h1><?php echo $p; ?></h1>
</body>

</html>
